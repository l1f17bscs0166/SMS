package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class activity4 extends AppCompatActivity {

    private RecyclerView myRecycleView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

        final SharedPreferences sharedpref1 = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num1=sharedpref1.getInt("count",0);
        String patntnames[]=new String[num1];
        for (int i = 0; i < num1; i++) {
        patntnames[i]=sharedpref1.getString("username"+i ,"");
        }

        myRecycleView =(RecyclerView) findViewById(R.id.recyclerView);
        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();

        for(int i=0;i<10;i++)
        {
            ListItem listitem =new ListItem("Item "+(i+1));
            listItems.add(listitem);
        }

        adapter = new myadaptor (this,listItems);
        myRecycleView.setAdapter(adapter);
     //   ListView myListView = findViewById(R.id.myList);

       // ArrayAdapter myArrayAdapter = new customAdapter (this, patntnames);

//        myListView.setAdapter(myArrayAdapter);

  //      myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

       //     @Override
         //   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //String playerName=String.valueOf(parent.getItemAtPosition(position));
               // Toast.makeText(MainActivity.this,playerName,Toast.LENGTH_LONG).show();


           //     String na,e,a,h,g,t;
             //   long number;
               // na=sharedpref1.getString("username"+position ,"");
            //    number=sharedpref1.getLong("myint"+position,0);
             //   e=sharedpref1.getString("Email"+position,"");
              //  h=sharedpref1.getString("Hospital"+position,"");
               // a=sharedpref1.getString("Address"+position,"");
               // t=sharedpref1.getString("Timing"+position,"");
               // g=sharedpref1.getString("Gender"+position,"");
               // showMessage("Data",na+"\n"+number+"\n"+e+"\n"+h+"\n"+a+"\n"+t+"\n"+g+"\n");
            //}
       // });


    }

    public void showMessage(String title,String Message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }


}
