package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Integer.parseInt;

public class Activity7 extends AppCompatActivity {

    EditText usernameinput;
    EditText passwordinput;
    EditText pass2input;

    EditText numberinput;
    EditText email;
    EditText hospital;
    EditText address;
    EditText timing;
    RadioGroup rg;
    TextView em,pa,in;
    int c=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);
        usernameinput=findViewById(R.id.editText6);
        passwordinput=findViewById(R.id.editText13);
        numberinput=findViewById(R.id.editText7);
        email=findViewById(R.id.editText8);
        hospital=findViewById(R.id.editText9);
        address=findViewById(R.id.editText10);
        timing=findViewById(R.id.editText11);
        rg=findViewById(R.id.radioGroup2);
        pass2input=findViewById(R.id.editText12);
        em=findViewById(R.id.textView5);
        pa=findViewById(R.id.textView6);
        in=findViewById(R.id.textView7);

    }
    public void savedocinfo(View view) {
        in.setText("");
        pa.setText("");
        em.setText("");
        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpref.edit();
        int num=sharedpref.getInt("count",0);
        c=num;
        String u,p,e,a,g,h,t,p2;
        long m;
        u=usernameinput.getText().toString();
        p=passwordinput.getText().toString();
        e=email.getText().toString();
        a=address.getText().toString();
        g=((RadioButton)findViewById(rg.getCheckedRadioButtonId())).getText().toString();

        p2=pass2input.getText().toString();
        h= hospital.getText().toString();
        t=timing.getText().toString();
        m=Long.parseLong(numberinput.getText().toString());

        if(u.length() == 0 || p.length() == 0 || e.length() == 0 || a.length() == 0 || g.length() == 0 || h.length() == 0 || t.length() == 0 || p2.length()==0)
        {
            in.setText("Input all fields");
            in.setTextColor(Color.RED);
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(e).matches())
        {
            em.setText("Email is not valid");
            em.setTextColor(Color.RED);
        }
        else
            {
                if (p2.equals(p)) {
                    editor.putString("username" + c, u);
                    editor.putString("password" + c, p);
                    editor.putLong("myint" + c, m);
                    editor.putString("Email" + c, e);
                    editor.putString("Hospital" + c, h);
                    editor.putString("Address" + c, a);
                    editor.putString("Timing" + c, t);
                    editor.putString("Gender" + c, g);
                    c++;
                    editor.putInt("count", parseInt(String.valueOf(c)));
                    editor.apply();
                    Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, activity6.class);
                    intent.putExtra("message",u);
                    startActivity(intent);
                } else {
                    pa.setText("Passwords Are not same.");
                    pa.setTextColor(Color.RED);

                }


            }
    }

}
