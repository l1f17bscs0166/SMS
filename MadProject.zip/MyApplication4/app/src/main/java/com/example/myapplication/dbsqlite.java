package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class dbsqlite extends SQLiteOpenHelper {


    public static final String databaseName = "dawai.db";
    public static final String tableNameAREA = "AREA";
    public static final String Col1A = "Sr_no";
    public static final String Col2A = "AREA_NAME";
    public static final String Col3A = "HOSPITAL_NAME";
    public static final String Col4A = "ADDRESS";
    public static final String Col5A = "PHONE_NO";


    public static final String tableName = "MEDICINE";
    public static final String Col1B = "Sr_no";
    public static final String Col2B = "Name";
    public static final String Col3B = "Dosage";
    public static final String Col4B = "Disease";
    public static final String Col5B = "Price";



    public dbsqlite(Context context)
    {
        super(context, databaseName, null, 2);
        SQLiteDatabase db = this.getWritableDatabase();//SqlLite handler 'db'.two options readable & writeable,Difference is when allocating memory and is not important.other wise it is same
    }

    String SQlStringAREA = "create table " + tableNameAREA +
            "("
            + Col1A + " Integer Primary Key Autoincrement, "
            + Col2A + " Text, "
            + Col3A + " Text, "
            + Col4A + " Text, "
            + Col5A + " Text" +
            ")";

    String SQlStringMRD = "create table " + tableName +
            "("
            + Col1B + " Integer Primary Key Autoincrement, "
            + Col2B + " Text, "
            + Col3B + " Text, "
            + Col4B + " Text, "
            + Col5B + " Text" +
            ")";


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQlStringAREA);
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('JOHAR TOWN LAHORE', 'LIFE LINE HOSPTAL', 'Building # 462, 463, Khokhar Chowk Block G 3 Phase 2 Johar Town،, Lahore, Punjab 54000', '(042) 35445684')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('JOHAR TOWN LAHORE', 'Doctors Hospital & Medical Center', '152-G/1، Canal Bank Road, Johar Town، Block G 1 Phase 1 Johar Town, Lahore, Punjab 54590', '(042) 35302701')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('JOHAR TOWN LAHORE', 'Union Hospital', 'Opposite University of Central, Khayaban-e-Jinnah, Iqbal Avenue Housing Society, Lahore, Punjab', '(042) 38910361')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('DHA LAHORE', 'National Hospital & Medical Center', '132/2 Street 123, Sector L Dha Phase 1, Lahore, Punjab', '(042) 111 171 819')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('DHA LAHORE', 'DHA Medical Centre Phase III', 'Street 29, Sector W Phase 3 DHA Phase 3, Lahore, Punjab 54792', '(042) 35745920')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('DHA LAHORE', 'Aadil Hospital', 'D.H.A. Main Blvd, DHA Phase 3, Lahore, Punjab 54000', '(042) 111 223 454')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('FASIAL TOWN LAHORE', 'Jinnah Hospital, Lahore', 'Usmani Rd, Quaid-i-Azam Campus, Lahore, Punjab 54550', '(042) 99231400')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('GULBERG TOWN LAHORE', 'Mayo Hospital', 'near New Anarkali، Neela Gumbad Lahore, Punjab 54000', '(042) 99211129')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('SAMANABAD LAHORE','SERVICES HOSPITAL', 'Ghaus-ul-Azam, Shadman Jail Road, Punjab، Lahore, 54000', '((042) 99203402')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('IQBAL TOWN LAHORE', 'Doctors Inn Hospital', '132 Main Boulevard Allama Iqbal Town, Jahanzeb Block Chenab Block Allama Iqbal Town, Lahore, Punjab 54000', '(042) 37801025')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('LAHORE CANTT', 'Fauji Foundation Hospital Lahore', 'House No 75-B, Alfalah Town Bedian Road Near Bhatta، Chowk، Cantt, Lahore, Punjab', '(042) 99220291')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('LAHORE CANTT', 'Combined Military Hospital Lahore', 'Abdul Rehman Rd, Saddar Town, Lahore, Punjab', '(042) 99221109')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('SHAHDARA LAHORE', 'Govt Hospital Shahdrah Town and EPI Center', 'Shahdara Town, Shahdara, Lahore, Punjab', '((042) 37947680')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('SHAHDARA LAHORE', 'Ibrahim Hospital', 'Shahdara Town, Shahdara, Lahore, Punjab', '(042) 37921026')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('ISLAMABAD', 'Shifa International Hospital', 'Pitras Bukhari Rd, H-8/4 H 8/4 H-8, Islamabad, Islamabad Capital Territory', ' (051) 8463000')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('ISLAMABAD', 'Unit 2, PAF Hospital Islamabad', ' Main Margalla Rd, E-9/1 E-9, Islamabad, Islamabad Capital Territory', '(051) 9567000')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('ISLAMABAD', 'CDA Hospital', 'Street 31, G-6/2 G 6/2 G-6, Islamabad, Islamabad Capital Territory', '(051) 9221334')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('ISLAMABAD', 'Islamabad Medical and Surgical Hospital', 'G-6 Markaz G 6 Markaz G-6, Islamabad, Islamabad Capital Territory', '(051) 2603566')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KARACHI', 'Abbasi Shaheed Hospital', 'Tabish Dehlavi Road, Block 3 Nazimabad, Karachi, Karachi City, Sindh 74600', ' (021) 99260400')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KARACHI', 'Jinnah Post Graduate Medical Center', 'Rafiqui، Sarwar Shaheed Rd, Karachi Cantonment, Karachi, Karachi City, Sindh 75510', '(021) 99201300')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KARACHI', 'Aga Khan University Hospital, Pakistan', 'National Stadium Rd, Aga Khan University Hospital, Karachi, Karachi City, Sindh 74800', '(021) 111 911 911')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KARACHI', 'The Indus Hospital', 'Plot C-76, Sector 31/5, Opposite، Crossing، Darussalam Society Sector 39 Korangi, Karachi, Karachi City, Sindh', '(021) 35112709')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('PESHAWAR', 'Lady Reading Hospital MTI Peshawar', 'Soekarno Rd, PTCL Colony Peshawar, Khyber Pakhtunkhwa 25000', '(091) 9211441')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('PESHAWAR', 'The Indus Hospital', 'University Rd, Rahat Abad, Peshawar, Khyber Pakhtunkhwa', '(091) 9224400')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('QUETTA', 'Combined Military Hospital', 'Cantonment, Quetta, Balochistan', '(081) 9202970')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('QUETTA', 'Quetta Hospital', 'Fatah Muhmmed Road، Quetta, Balochistan', '(081) 2829915')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KASHMIR', 'CMH Rawalakot', 'Rawalakot-Muzaffarabad Rd, Rawalakot Cantt, Rawalakot, AJK', 'NOT AVALIBLE')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('KASHMIR', 'SKBZ CMH Muzaffarabad', 'CMH Rd, Muzaffarabad, Azad Jammu and Kashmir', '(058229)20451')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('FAISALBAD', 'Shifa International Hospital Ltd. Faisalabad', 'Main Jaranwala Rd, Faisalabad, Punjab 38000', '(041) 8740951')");
        db.execSQL("INSERT INTO " + tableNameAREA + "(AREA_NAME, HOSPITAL_NAME, ADDRESS, PHONE_NO ) VALUES ('FAISALBAD', 'Allied Hospital', 'Dr. Tusi Rd, Faisalabad, Punjab', '(041) 9210082')");


        db.execSQL(SQlStringMRD);
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Brufen', '1-tbl Spoon', 'Fever', 'Rs.90')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Motilium', 'Take Before Meal', 'Vomiting', 'Rs.103')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Surbex z', '1-tbl Daily', 'Multivitamin', 'Rs.209 - 1x30')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Disprin', '1 tablet', 'Headaches', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Trisil', 'Advice of Doctor', 'Fever', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Dicloran Gel 20.GM', 'Advice of Doctor', 'Fever', 'Rs.96.89/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Ansaid', 'Advice of Doctor', 'Osteoarthritis', 'Rs.246/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Flagyl 400mg', 'Advice of Doctor', 'intestine', 'Rs.2.17/tablet')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Arinac Tab 200mg', 'Advice of Doctor', 'moderate pain', 'Rs.3.03/tablet')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Hydryllin', 'Advice of Doctor', 'Cough', 'Rs.69')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Chloramphenicol', 'Advice of Doctor', 'Typhoid fever', 'Rs.28/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Amoxicillin', 'Advice of Doctor', 'tonsillitis', 'Rs.0')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Polyfax', 'Apply on Your skin', 'Skin infection-external Use', 'Rs.106')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Caflam 50mg', 'Advice of Doctor', 'dental pain', 'Rs.92')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Nise 100mg', 'Advice of Doctor', 'Body pain', 'Rs.132')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Amoxil', 'Advice of Doctor', 'bronchitis', 'Rs.81.67/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Rigix 5mg', 'Advice of Doctor', 'Anti-allergy', 'Rs.113')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Risek 20mg', 'Advice of Doctor', 'Stomatch pain', 'Rs.123')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Gravinate', 'Advice of Doctor', 'motion', 'Rs.40')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Novidat 500mg', 'Advice of Doctor', 'Stomach infections', 'Rs.300/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('kestine 10mg', 'Advice of Doctor', 'sneezing', 'Rs.163.5/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Zestril', 'Take Before Bed Time', 'Heart issue', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Ibuprofen 200mg Tablet', 'Advice of Doctor', 'Leg Pain', 'Rs.2324/Pack')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Ivermectin', 'Advice of Doctor', 'kills lice', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Aspirin', 'Advice of Doctor', 'Chest Pain', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Ramelteon', 'Advice of Doctor', 'treat insomnia', 'Rs.20')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Naproxen', 'Advice of Doctor', 'Cramps', 'Rs.2,163-40 tablets')");
        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Advil', 'Advice of Doctor', 'Sore Throat', 'Rs.930')");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + tableNameAREA);//
        db.execSQL("drop table if exists " + tableName);//drop table means delete and if exists means if it is not null.
        onCreate(db);

    }
    public Cursor getdataofcity(String c)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor result1=db.rawQuery("select * from "+tableNameAREA+" where AREA_NAME = ? ",new String[]{c});
        return result1;

    }
    //////////////////////////////activity
    public Cursor getdata(String a)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor result=db.rawQuery("select * from "+tableName+" where Disease = ? ",new String[]{a});
        return result;

    }

    public Cursor getdataofmed(String m)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor result5=db.rawQuery("select * from "+tableName+" where Name = ? ",new String[]{m});
        return result5;

    }

 /////////////////activity 14/////////////////////////////////////////
    public boolean insertData(String Name,String Dosage,String Disease,String Price){
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues contentToAdd =new ContentValues();

        contentToAdd.put (Col2B,Name);
        contentToAdd.put (Col3B,Dosage);
        contentToAdd.put (Col4B,Disease);
        contentToAdd.put (Col5B,Price);

        long result1=db.insert(tableName,null,contentToAdd);

        if(result1==-1)
            return false;
        else
            return true;
    }

    public boolean updateData(String Name,String Dosage,String Disease,String Price)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues newValues =new ContentValues();
        newValues.put(Col2B,Name);
        newValues.put(Col3B,Dosage);
        newValues.put(Col4B,Disease);
        newValues.put(Col5B,Price);
        db.update(tableName,newValues,"Disease = ?",new String[]{Disease});


        return true;
    }
    public Cursor getAllDataR()
    {
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor result2 = db.rawQuery("select * from " + tableName,null);
        return result2;
    }
    public Integer deleteData(String Disease)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        return db.delete(tableName,"Disease = ?",new String[]{Disease});
    }
    ///////////////////////activity 14/////////////////////////////////////////
}